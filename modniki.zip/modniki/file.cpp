#include "global.h"
#include "file.h"
// запись в файл одной вещи
int w_write (std::ostream & stream,const thing &all)
{
 int i;
 
 stream<<all.type<<"\n";
 if (all.z==head) i=head;
 if (all.z==ears) i=ears;
 if (all.z==torso) i=torso;
 if (all.z==back) i=back;
 if (all.z==arms) i=arms;
 if (all.z==legs) i=legs;
 if (all.z==foots) i=foots;
 
 
 stream<<i<<"\n";
 stream<<all.color<<"\n";
 stream<<all.like<<"\n";
 
 return 1;

}
//запись в файл глобального гардероба
int write (global &ob)
{
 int i;
 std::ofstream fox("namefile");
 if (ob.all.size()>0)
             {
              w_write(fox,ob.all[0]);
              for (i=1;i<ob.all.size();i++)
                 {
                  fox<<"\n";
                  w_write(fox,ob.all[i]);
                 }
             
             }

 fox.close();

}

//чтение из файла одной вещи
int r_read (std::istream & stream,thing &all)
{
 int i;
 stream>>all.type;
 
 stream>>i;
 if (i==head) all.z=head;
 if (i==ears) all.z=ears;
 if (i==torso) all.z=torso;
 if (i==back) all.z=back;
 if (i==arms) all.z=arms;
 if (i==legs) all.z=legs;
 if (i==foots) all.z=foots;
 
 stream>>all.color;
 stream>>all.like;
 
 return 1;

}

//чтение глобального гардероба
int read (global &ob)
{
 std::ifstream fin("namefile");
 int i=0;
 ob.all.clear();

 if (!fin)
         {
          return 0;
         }
 ob.all.push_back(thing());

 while(1)
        {
         if (fin.eof()==1) break;
         ob.all.push_back(thing());
         r_read(fin,ob.all[i]);
         i++;
        }        
        ob.all.pop_back();
        ob.all.pop_back();
 fin.close();
 return 1;        

}
