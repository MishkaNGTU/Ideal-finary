///запись в файл глобального гардероба
int write (std::vector<thing> &all);
///чтение из файла глобального гардероба
int read (std::vector<thing> &all);
