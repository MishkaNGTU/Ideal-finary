#include "global.h"


int global::add_thing() //ДОБАВИТЬ ВЕЩЬ
{   
    
    int lik,p;
    enum location y;
    char *col = new char[80], *tip = new char[80];
   
   
   std:: cout << "\n" << "Введите локацию: "<< "\n\n";
   std:: cout << "\n" << "0 - Head";
   std:: cout << "\n" << "1 - Ears";
   std:: cout << "\n" << "2 - Torso";
   std:: cout << "\n" << "3 - Back";
   std:: cout << "\n" << "4 - Arms";
   std:: cout << "\n" << "5 - Legs";
   std:: cout << "\n" << "6 - Foots";
   
   do {
   
      std:: cout << "\n\n" << "Ваш выбор: ";
      std:: cin >> p;
   
   }while ((p<0)||(p>6));
   
    
   std::cout << "\n" <<"Введите локацию: ";
  
  if (p==0) std::cout << "Head";
  if (p==1) std::cout << "Ears";
  if (p==2) std::cout << "Torso";
  if (p==3) std::cout << "Back";
  if (p==4) std::cout << "Arms";
  if (p==5) std::cout << "Legs";
  if (p==6) std::cout << "Foots";
  std::cout << "\n";
    
   if (p==head) y=head;
   if (p==ears) y=ears;
   if (p==torso) y=torso; 
   if (p==back) y=back;
   if (p==arms) y=arms;
   if (p==legs) y=legs;
   if (p==foots) y=foots;
  
   
   
   std:: cout << "Введите тип: ";
   std:: cin >> tip;
    
   std:: cout << "Введите цвет: ";
   std:: cin >> col;
    
   std:: cout << "Введите количество лайков: ";
   std:: cin >> lik;
    
   all.push_back (thing(lik,y,col,tip));
  
   
   std::cout << "\n" << "Вещь добавлена!";
    
    return 1;
}


int global::watch_thing() //ВЫВОД
{
   int i;
  
   if (all.empty()==0)
    {
       
        for (i=0;i<all.size();i++)
          {
           std::cout<<"\n\n"<<"-------------------" << "\n";
           std::cout<< " Индекс: " << i ;
           all[i].show();
          }
          std::cout<<"\n";  
    
    } else std::cout << "\n"  << "Гардероб пуст" << "\n";


}

int global::know_id_thing()
{   

   system ("clear");
   char next;
   int p,i,flag=0,id;
   std::cout << "\n" <<"Выберите локацию и мы предложим вам пару вещей." << "\n";
   
   
   std:: cout << "\n" << "0 - Head";
   std:: cout << "\n" << "1 - Ears";
   std:: cout << "\n" << "2 - Torso";
   std:: cout << "\n" << "3 - Back";
   std:: cout << "\n" << "4 - Arms";
   std:: cout << "\n" << "5 - Legs";
   std:: cout << "\n" << "6 - Foots";
   
   do{ 
       std::cout<<" \n\n" <<"Ваш выбор: ";
       std::cin>>p;
   } while ((p<0)||(p>6));


  
   system("clear");  
   if (all.empty()==0)
    {
       
        for (i=0;i<all.size();i++)
          {
          if (all[i].get_location()==p)
               {
                  flag=1;
                  std::cout<<"\n\n"<<"-------------------" << "\n";
                  std::cout<< " Индекс: " << i ;
                  all[i].show();
               
               }
          
          }
          std::cout<<"\n";  
    
    } else {system("clear"); std::cout << "\n"  << "Гардероб пуст" << "\n";return -1;}
    
    if (flag==0){system("clear"); std::cout << "\n\n" << "!!Нет таких вещей!!"<<"\n\n"; return -1;} 

    std::cout << "\n" << "Введите индекс выбранной вещи: ";
    std::cin >> id;
    
    if ((id>all.size())||(id<all.size()))
    if (p!=all[id].get_location()) {system("clear"); std::cout << "\n\n" << "!!!Некоректный ввод!!!"<<"\n\n";return -1;}
    system("clear");
    return id;

}


int global::watch_one_thing(int i)
{
    if(i<0) return 0;
    if(i>all.size()-1) return 0;
    std::cout<<"\n\n"<<"-------------------" << "\n";
    std::cout<< " Индекс: " << i ;
    all[i].show();
    
    return 1;
}

int global::watch_user_thing(const std::vector<int> &staff)
{
 
  int i;
        if (staff.empty()==0)
        {    
          
          for (i=0;i<staff.size();i++)
            {
              watch_one_thing(staff[i]);
            }
        } else {std::cout << "\n"  << "У вас нет ни одной вещи в вашем гардеробе" << "\n";}

return 1;
} 



