#include <vector>
#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include "thing.h"

class global { //<глобальный гардероб

 std::vector <thing> all; //< вектор, заполненный вещами.
  
  public:
  
  ///добавление вещи в гардероб
  int add_thing();      
  
  ///вывод всего гардероба
  int watch_thing();    
  
  ///вывод одной вещи
  int watch_one_thing(int i);
 
  ///узнаем ID вещи(функция возвращает ID и передает в другую функцию в классе user)
  int know_id_thing();
 
  ///подбор наряда
  int get_finary(const std::vector<int> &staff);
  
  ///вывод гардероба пользователя
  int watch_user_thing(const std::vector<int> &staff);
  
  ///запись глобального гардероба в файл
  friend int write (global &ob);
  
  ///чтение глобального гардероба из файла
  friend int read (global &ob); 
  
  ///выбранные пользователем вещи, записываются в векто user_choose
  int user_variety (const std::vector<int> &staff, std::vector<int> &user_choose);
  
  /// на основе вектора user_choose и staff формируется вектор good_thing
  int user_good_thing (const std::vector<int> &staff,const std::vector<int> &user_choose,std::vector<int> &good_thing);
  
  /// из good_thing в best_thing выбираются лучшие вещи
  int user_best_thing (const std::vector<int> &good_thing, std::vector<int> &best_thing);
  
  /// пользователь решает оставить предложенный наряд или заменить какую-нибудь вещь
  int user_decision (int &flag, std::vector<int> &best_thing, std::vector<int> &good_thing);
 
  /// исключение из good_thing непонравившейся вещи 
  int user_notliked (std::vector<int> &best_thing, std::vector<int> &good_thing);  
};
   
