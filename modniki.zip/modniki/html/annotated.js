var annotated =
[
    [ "global", "classglobal.html", "classglobal" ],
    [ "thing", "classthing.html", "classthing" ],
    [ "user", "classuser.html", "classuser" ]
];