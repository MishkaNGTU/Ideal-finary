var classglobal =
[
    [ "add_thing", "classglobal.html#ab5095dfd4bdf53b5f6222995ce6d4141", null ],
    [ "get_finary", "classglobal.html#ab91161046c7c01a08272719c16b54187", null ],
    [ "know_id_thing", "classglobal.html#a199f8dd4c5d36536e23108d6df12c137", null ],
    [ "user_best_thing", "classglobal.html#a9e5b6f86b0f0920a565c81e9a4f29a21", null ],
    [ "user_decision", "classglobal.html#ae8de1b5c08be814dc600472fb327f69d", null ],
    [ "user_good_thing", "classglobal.html#aad21b4e68180364286f172ef7cea43e1", null ],
    [ "user_notliked", "classglobal.html#a760f6458aca4bb9650c7d5399c43d95e", null ],
    [ "user_variety", "classglobal.html#a65db84b1bb6a3fcbe24d536fc0d9ba0d", null ],
    [ "watch_one_thing", "classglobal.html#a5098b3bc020d5093c8101639df264593", null ],
    [ "watch_thing", "classglobal.html#a54d454808e2113f3b4060a3c6231a250", null ],
    [ "watch_user_thing", "classglobal.html#a30202a9130078a6570a72010908743fc", null ],
    [ "read", "classglobal.html#aa1bae20335d8fc53d6f8622e6c918bea", null ],
    [ "write", "classglobal.html#a0f45b73ea9fe485ce592468d07492493", null ]
];