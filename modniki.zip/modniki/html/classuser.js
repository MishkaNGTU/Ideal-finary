var classuser =
[
    [ "user", "classuser.html#af69e12ac02b13145db5422fcff9081c9", null ],
    [ "get_staff", "classuser.html#aca0f131dd8daf48d09ccbc3958656ba5", null ],
    [ "user_add_thing", "classuser.html#a5a18653158f7b080354f67120d0de9fc", null ],
    [ "user_delete_thing", "classuser.html#a59a61861f465f12b6b47f3fed992a311", null ],
    [ "userread", "classuser.html#a2a24ea5b6f3f56701ba9dbd8799c48b3", null ],
    [ "userwrite", "classuser.html#ac83ceeb81034d393e10dd51d84455baa", null ]
];