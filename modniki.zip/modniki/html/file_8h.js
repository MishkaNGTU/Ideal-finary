var file_8h =
[
    [ "read", "file_8h.html#af376f5889486c2b9a2c7f39abffbdb7b", null ],
    [ "write", "file_8h.html#aec4a78784d4d1479f68fff1612e7c9b0", null ]
];