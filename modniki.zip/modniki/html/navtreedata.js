var NAVTREE =
[
  [ "Идеальный наряд", "index.html", [
    [ "Классы", null, [
      [ "Классы", "annotated.html", "annotated" ],
      [ "Алфавитный указатель классов", "classes.html", null ],
      [ "Члены классов", "functions.html", [
        [ "Указатель", "functions.html", null ],
        [ "Функции", "functions_func.html", null ],
        [ "Относящиеся к классу функции", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Файлы", null, [
      [ "Файлы", "files.html", "files" ],
      [ "Список членов всех файлов", "globals.html", [
        [ "Указатель", "globals.html", null ],
        [ "Функции", "globals_func.html", null ],
        [ "Перечисления", "globals_enum.html", null ],
        [ "Элементы перечислений", "globals_eval.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'нажмите на выключить для синхронизации панелей';
var SYNCOFFMSG = 'нажмите на включить для синхронизации панелей';