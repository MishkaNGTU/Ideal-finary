var searchData=
[
  ['add_5fthing',['add_thing',['../classglobal.html#ab5095dfd4bdf53b5f6222995ce6d4141',1,'global']]],
  ['arms',['arms',['../thing_8h.html#a5f269c22e6d9d32b0b0ad7e6166854dfab1736dd93e52da2c281f2caa31b51526',1,'thing.h']]]
];
