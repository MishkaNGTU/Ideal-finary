var searchData=
[
  ['thing',['thing',['../classthing.html',1,'thing'],['../classthing.html#ae912333a6e8350ee2eea09485ad287de',1,'thing::thing()'],['../classthing.html#a79d7b64aacf94c0348f41818bc8d4221',1,'thing::thing(int lik, enum location y, char *col, char *tip)']]],
  ['thing_2ecpp',['thing.cpp',['../thing_8cpp.html',1,'']]],
  ['thing_2eh',['thing.h',['../thing_8h.html',1,'']]],
  ['torso',['torso',['../thing_8h.html#a5f269c22e6d9d32b0b0ad7e6166854dfa826a07630da56db817c221d1563e93ec',1,'thing.h']]],
  ['twinmenu',['twinmenu',['../menu_8cpp.html#a39574f3d9525013f2aa37e01ba617aa3',1,'twinmenu(global &amp;ob):&#160;menu.cpp'],['../menu_8h.html#a39574f3d9525013f2aa37e01ba617aa3',1,'twinmenu(global &amp;ob):&#160;menu.cpp']]]
];
