var searchData=
[
  ['global',['global',['../classglobal.html',1,'']]]
];
