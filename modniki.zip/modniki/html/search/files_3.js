var searchData=
[
  ['podbor_2ecpp',['podbor.cpp',['../podbor_8cpp.html',1,'']]]
];
