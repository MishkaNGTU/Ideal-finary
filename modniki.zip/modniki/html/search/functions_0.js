var searchData=
[
  ['add_5fthing',['add_thing',['../classglobal.html#ab5095dfd4bdf53b5f6222995ce6d4141',1,'global']]]
];
