var searchData=
[
  ['dislike',['dislike',['../classthing.html#a7f36dbe13024ef29a86586ce89afc8b1',1,'thing']]]
];
