var searchData=
[
  ['get_5ffinary',['get_finary',['../classglobal.html#ab91161046c7c01a08272719c16b54187',1,'global']]],
  ['get_5flike',['get_like',['../classthing.html#acfa5cf2f38ed6fe90b0e3660bf55cb5e',1,'thing']]],
  ['get_5flocation',['get_location',['../classthing.html#a9a7b24b6c81ad40b494cda81467d57f6',1,'thing']]],
  ['get_5fstaff',['get_staff',['../classuser.html#aca0f131dd8daf48d09ccbc3958656ba5',1,'user']]]
];
