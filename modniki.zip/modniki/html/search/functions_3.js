var searchData=
[
  ['know_5fid_5fthing',['know_id_thing',['../classglobal.html#a199f8dd4c5d36536e23108d6df12c137',1,'global']]]
];
