var searchData=
[
  ['thing',['thing',['../classthing.html#ae912333a6e8350ee2eea09485ad287de',1,'thing::thing()'],['../classthing.html#a79d7b64aacf94c0348f41818bc8d4221',1,'thing::thing(int lik, enum location y, char *col, char *tip)']]],
  ['twinmenu',['twinmenu',['../menu_8cpp.html#a39574f3d9525013f2aa37e01ba617aa3',1,'twinmenu(global &amp;ob):&#160;menu.cpp'],['../menu_8h.html#a39574f3d9525013f2aa37e01ba617aa3',1,'twinmenu(global &amp;ob):&#160;menu.cpp']]]
];
