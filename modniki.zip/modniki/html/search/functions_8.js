var searchData=
[
  ['uplike',['uplike',['../classthing.html#a8fa6783ba20f9f17686fa75440717eab',1,'thing']]],
  ['user',['user',['../classuser.html#af69e12ac02b13145db5422fcff9081c9',1,'user']]],
  ['user_5fadd_5fthing',['user_add_thing',['../classuser.html#a5a18653158f7b080354f67120d0de9fc',1,'user']]],
  ['user_5fbest_5fthing',['user_best_thing',['../classglobal.html#a9e5b6f86b0f0920a565c81e9a4f29a21',1,'global']]],
  ['user_5fdecision',['user_decision',['../classglobal.html#ae8de1b5c08be814dc600472fb327f69d',1,'global']]],
  ['user_5fdelete_5fthing',['user_delete_thing',['../classuser.html#a59a61861f465f12b6b47f3fed992a311',1,'user']]],
  ['user_5fgood_5fthing',['user_good_thing',['../classglobal.html#aad21b4e68180364286f172ef7cea43e1',1,'global']]],
  ['user_5fnotliked',['user_notliked',['../classglobal.html#a760f6458aca4bb9650c7d5399c43d95e',1,'global']]],
  ['user_5fvariety',['user_variety',['../classglobal.html#a65db84b1bb6a3fcbe24d536fc0d9ba0d',1,'global']]],
  ['usermenu',['usermenu',['../menu_8cpp.html#a011381f6dc2c1bbe3aac438e1fb11d14',1,'usermenu():&#160;menu.cpp'],['../menu_8h.html#a011381f6dc2c1bbe3aac438e1fb11d14',1,'usermenu():&#160;menu.cpp']]],
  ['userread',['userread',['../classuser.html#a2a24ea5b6f3f56701ba9dbd8799c48b3',1,'user']]],
  ['usertwinmenu',['usertwinmenu',['../menu_8cpp.html#a27c4f8bb8c8722c4e14ca8af016717ef',1,'usertwinmenu():&#160;menu.cpp'],['../menu_8h.html#a27c4f8bb8c8722c4e14ca8af016717ef',1,'usertwinmenu():&#160;menu.cpp']]],
  ['userwrite',['userwrite',['../classuser.html#ac83ceeb81034d393e10dd51d84455baa',1,'user']]]
];
