var searchData=
[
  ['r_5fread',['r_read',['../classthing.html#a6a2f5ac2f7f19b99d19f652371152bd0',1,'thing']]],
  ['read',['read',['../classglobal.html#aa1bae20335d8fc53d6f8622e6c918bea',1,'global']]]
];
