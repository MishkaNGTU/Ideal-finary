var indexSectionsWithContent =
{
  0: "abdefghklmprstuw",
  1: "gtu",
  2: "fgmptu",
  3: "adgkmrstuw",
  4: "l",
  5: "abefhlt",
  6: "rw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "related"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Перечисления",
  5: "Элементы перечислений",
  6: "Друзья"
};

