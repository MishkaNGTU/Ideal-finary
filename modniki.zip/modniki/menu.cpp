#include "global.h"
#include "file.h"
#include "user.h"

int menu()
{
 int c;
 
 std::cout << "\n\n";
 std::cout << "1. Добавить вещь в гардероб" << "\n";
 std::cout << "2. Показать весь гардероб" << "\n"; 
 std::cout << "3. Назад" << "\n"; 
  do
  {
   std::cout << "\n" << "Введите нужный номер: ";
   std::cin >> c;
  
  } while (c<1||c>3);
  return c;
  
}

int twinmenu(global &ob)
{
 
 char p;
  
 for(;;)
       {
        
        p=menu();
        switch (p)
                 {
                    case 1:system("clear");
                           ob.add_thing();
                           write(ob);
                    break;
                    
                    case 2:system("clear");
                           read(ob);
                           ob.watch_thing();
                    break;
                    
                    case 3:system("clear");
                           return 1;
                    break;
                 
                 }      
                     
       
       }



 return 1;
}

int usermenu()
{
 int c;

 std::cout << "\n\n";
 std::cout << "1. Добавить вещи в свой гардероб"<< "\n";
 std::cout << "2. Показать свой гардероб" << "\n"; 
 std::cout << "3. Подобрать наряд" << "\n";
 std::cout << "4. Удалить вещь из своего гардероба" << "\n";
 std::cout << "5. Работа с глобальным гардеробом" << "\n";
 std::cout << "6. Выход" << "\n";
  do
  {
   std::cout << "\n" << "Введите нужный номер: ";
   std::cin >> c;
  
  } while (c<1||c>6);
  return c;
  
}



int usertwinmenu()
{

 system ("clear");
 global ob;
 int y,index;
 char nickname[80];
 std::cout << "Введите свой никнэйм: ";
 std::cin >> nickname;
 user man(nickname);
 system ("clear");
 char p;
  
 for(;;)
       {
        read(ob);
        p=usermenu();
        switch (p)
                 {
                    case 1:system ("clear");
                           man.userread();
                           y=ob.know_id_thing(); 
                           man.user_add_thing(y);
                           man.userwrite();
                    break;
                    
                    case 2:system ("clear");
                           man.userread(); 
                           ob.watch_user_thing(man.get_staff());
                    break;
                    
                    case 3:system ("clear");
                           man.userread();
                           ob.get_finary(man.get_staff());
                           write(ob);
                           man.userwrite();
                    break;
                    
                    case 4:system ("clear");
                           man.userread();
                           ob.watch_user_thing(man.get_staff());
                           man.user_delete_thing();
                           man.userwrite();
                    break;
                    
                    case 5:system ("clear");
                           twinmenu(ob);
                    break;
                 
                    case 6:return 1;
                    break;
                 
                 }      
       
       
       
       
       }
       
return 0;

}
