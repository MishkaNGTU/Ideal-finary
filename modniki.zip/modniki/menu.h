#include "global.h"
int menu();
int twinmenu(global &ob);
int usermenu();
int usertwinmenu();