#include "global.h"

int global::get_finary(const std::vector<int> &staff)
{
    
   
    std::vector<int> user_choose;// вектор, содержащий вещи, которые пользователь хочет надеть.
    std::vector<int> good_thing; // вектор, содержащий вещи, которые пользоваетль готов надеть.   
    std::vector<int> best_thing; // вектор, содержащий вещи, которые предложит пользователю программа;
    int i,p,flag=0;
    char l; 
    
       
      if (staff.empty()==0)// проверяем пустой ли гардероб пользователя. для удобства,если он не пустой, выводим его.
        {    
          
          for (i=0;i<staff.size();i++)
            {
              watch_one_thing(staff[i]);
            }
        
        } else {std::cout << "\n"  << "В вашем гардеробе нет вещей" << "\n";return 1;}

     
      user_variety(staff,user_choose);// функция, в которой пользователь выбирает вещи
                                      // заполнение вектора user_choose  
     
        user_good_thing(staff,user_choose,good_thing);// функция, которая заполняет вектор good_thing  
       
   while(1)
     {
        if (flag==0)
       {          
        user_best_thing(good_thing,best_thing);// функция выбирает лучшие вещи и выводит их    
      
        flag=user_decision(flag,best_thing,good_thing); // функция определяет, завершить подбор или исправить подборку вещей      
                    
       }else break;
     }     
     
return 1;

}


int global::user_decision(int &flag, std::vector<int> &best_thing, std::vector<int> &good_thing)
{
        int i,p,r;
        char l; 
        
        
        std::cout << "\n\n"  << "Для завершения введите - 1" << "\n";
        std::cout << "Для отказа введите - 2";
      
      
           do {
                 std::cout << "\n\n" <<"Ваш выбор: ";
                 std::cin >> p;
              }while ((p>2)||(p<1));
           l=p;
      
               switch(p) 
                      {
                        case 1: for(i=0;i<best_thing.size();i++) all[best_thing[i]].uplike();  
                                flag=1;
                        break;
                        
                        case 2:r=user_notliked (best_thing, good_thing);if (r==-1) flag=1;
                        break;
                      
                      }     
  

    return flag;

}


int global::user_variety (const std::vector<int> &staff, std::vector<int> &user_choose)
{
    int g, i,flag;

    while(1) // тут пользователь выбирает вещи, которые наденет и к ним уже будет подбираться наряд.
     { 
       std::cout <<"\n\n" <<"Что вы хотите надеть ? Введите индекс(для прекращения выбора введите -1): ";   
       std::cin>>g;
       
       if (g==-1) break; 
          
          flag=0;
          for (i=0;i<staff.size();i++)
            {
              if (g==staff[i]){ 
                                user_choose.push_back(g); // происходит заполнение вектора user_choose  
                                flag = 1; 
                              }    
            }
          if (flag==0) {std::cout <<"\n"<< "Неверный индекс"<<"\n";return 1;}
       
     }



}

int global::user_good_thing (const std::vector<int> &staff,const std::vector<int> &user_choose,std::vector<int> &good_thing)
{
   int i,j,flag;    
       
       for (i=head; i<(foots+1);i++)                   // цикл заполнения вектора good_thing
         {
           flag=0;
           for(j=0;j<user_choose.size();j++)             // проходимся по вектору user_choose
             if(i==all[user_choose[j]].get_location())   // выбранную вещь(индекс из user_choose) уже точно добавляем в вектор good_thing
                                                         // и поднимаем флаг. В локации выбранной вещи будет находится только эта вещь.  
                   {
                   flag=1;
                   good_thing.push_back(user_choose[j]);
                   }
           if(flag==0)                                  // если флаг опущен, значит в этой локации пользователь ничего не выбирал
                                                         // и мы вынуждены записать в вектор good_thing все вещи из этих локаций из гардероба
                                                         // пользователя, т.е из вектора staff. В дальнейшем из этих локаций будет 
                                                         // выбираться уже одна вещь с наибольшим лайком.  
           
          
           for( j=0;j<staff.size();j++)
             { 
               
               if(i==all[staff[j]].get_location())
                   good_thing.push_back(staff[j]);
               
             }
         } 

}



int global::user_best_thing (const std::vector<int> &good_thing, std::vector<int> &best_thing)
{
  int i,j,index;  
  for (i=head; i<(foots+1);i++)                       // Идем по локациям. цикл заполнения вектора best_thing, из которого и будет предлагаться
                                                          // подобранный наряд
      {
         index=-1;     
         for (j=0;j<good_thing.size();j++)    // перебираем все вещи из good_thing
           {
            
              if (i==all[good_thing[j]].get_location())    // если i - это локация вещи из вектора good_thing      
                   {
                     if (index==-1) {index=good_thing[j];} // если index=-1, этому индексу присваивается индекс из good_thing
                                                           // то есть даем сигнал, что в этой локации уже будет вещь.
                    
                      else // если индекс уже был сменен(т.е он уже не -1), значит тут несколько вещей из этой локации 
                        {
                         if (all[good_thing[j]].get_like()>all[index].get_like()) index=good_thing[j]; // выбираем вещь по наибольшему лайку.
                        }
                  }
           }      
       
     
        if (index==-1){ std::cout << "\n\n" << "!!!Для локации "; 

                      if (i==head) std::cout << "Head  ";
                      if (i==ears) std::cout << "Ears  ";
                      if (i==torso) std::cout <<"Torso ";
                      if (i==back) std::cout << "Back  ";
                      if (i==arms) std::cout << "Arms  ";
                      if (i==legs) std::cout << "Legs  ";
                      if (i==foots) std::cout <<"Foots ";
                      std::cout << "нет вещей. Но вы можете пополнить свой гардероб!!!";
                     } 
        best_thing.push_back(index); // заполняем вектор best_thing.    
        
      }
    std::cout << "\n\n" << "                          Мы подобрали вам наряд из ваших вещей" << "\n";  
    
    for (i=0;i<best_thing.size();i++)
    {
     watch_one_thing(best_thing[i]);
    }     
 

}

int global::user_notliked (std::vector<int> &best_thing,std::vector<int> &good_thing)
{
  int n,i,flag=0,j;
  
  std::cout << "\n\n" << "Введите индекс вещи, которая вам не понравилась: ";
  std::cin >> n;
  
       for (i=0;i<best_thing.size();i++)
         {
          if (n==best_thing[i]) {
                                    for (j=0;j<good_thing.size();j++)
                                     {
                                      if (n==good_thing[j]) good_thing.erase(good_thing.begin()+j);
                                     }
                                   
                                   all[best_thing[i]].dislike();
                                   flag=1;
                                   best_thing.clear();
                                }
         }
            if (flag==0) {std::cout << "\n\n" << "Неверный индекс"; return -1;}
     
        std::cout << "\n\n" << "Мы произведем новую подборку!" << "\n\n";   
     
        
        return 0;
}

