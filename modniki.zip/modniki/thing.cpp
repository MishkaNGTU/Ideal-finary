#include "global.h"

thing::thing()
{

  like=0;
  z=head;
  color = new char[80];
  type = new char[80];

}


int thing::show()
{

 std::cout << "\n Локация: "<<std::left;
 if (z==head) std::cout << "Head  ";
 if (z==ears) std::cout << "Ears  ";
 if (z==torso) std::cout <<"Torso ";
 if (z==back) std::cout << "Back  ";
 if (z==arms) std::cout << "Arms  ";
 if (z==legs) std::cout << "Legs  ";
 if (z==foots) std::cout <<"Foots ";
 
 std::cout << " Тип: " << std::setw(20)<<std::left<< type;
 std::cout << " Цвет: "<< std::setw(20)<<std::left << color;
 std::cout << " Количество лайков: "<< std::setw(20)<<std::left << like;

}


thing::thing(int lik, location y, char *col, char *tip)
{
   
    like=lik;
    z=y;
    color = new char[80];
    strcpy (color,col); 
    type = new char[80];
    strcpy (type,tip);
                         
}

int thing::get_location()
{
 return z; 
}

int thing::get_like()
{
 return like;
}

int thing::uplike()
{
  like++;
} 

int thing::dislike()
{
  like--;
}                        