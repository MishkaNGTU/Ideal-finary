enum location{head,ears,torso,back, arms,legs,foots};

//класс вещь
class thing { 
  
  ///локация на теле
  enum location z; 
  
  /// количество лайков вещи
  int like;       

  /// цвет и тип вещи
  char *color, *type;   
  
  public:
  thing();   
  
  /// инициализация
  thing (int lik,enum location y, char *col, char *tip);

  /// возвращает количество лайков
  int get_like(); 
  
  /// повышает количество лайков вещи на 1
  int uplike (); 
  
  /// уменьшает количество лайков вещи на 1
  int dislike(); 
  
  /// вывод данных вещи
  int show();     
  
  /// возвращает локацию вещи
  int get_location();
  
  /// запись в файл одной вещи
  friend int w_write (std::ostream & stream,const thing &all); 
  
  /// чтение из файла одной вещи
  friend int r_read (std::istream & stream,thing &all);        
};

