#include "user.h"
#include "global.h"

user::user(char usnam[80])
{
 strcpy(username,usnam);
}



int user::user_add_thing(int p)
{
  int i,flag=0;

  for (i=0;i<staff.size();i++)
      {
        if (p==staff[i]) flag=1;
      }
  
  if ((p!=-1)&&(flag==0))
  {
   staff.push_back(p);
   std::cout << "\n" << "Вещь добавлена" << "\n"; 
  }
  if (flag==1) std::cout << "\n"<< "У вас есть такая вещь" << "\n";

}


int user::user_delete_thing()
{
  int z,i,flag=0;

 
  if (staff.empty()==0)
  { 
  
  std::cout << "\n\n" << "Введите индекс вещи, которую хотите удалить: ";
  std::cin >> z;
   
   for (i=0; i<staff.size(); i++)
   {
      if (staff[i]==z) 
                     {
                     
                      staff.erase(staff.begin()+i); 
                      flag=1;
                      std::cout << "\n"<< "Вещь выброшена" << "\n";
                      break;
                     
                     }
  
   }
 
  if (flag==0) {  std::cout << "\n" << "!!!Нет вещей с таким индексом!!!";}
  }else { std::cout << "\n" << "Ваш гардероб пуст"<<"\n";}
  return 1;


}


std::vector<int>& user::get_staff()
{ 
     return staff;
} 
