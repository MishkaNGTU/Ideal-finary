#include "global.h"
#include "user.h"

int user::userwrite ()
{
 int i;
 std::ofstream fox (username);
 if (staff.size()>0)
                 {
                  fox << staff[0];
                  
                  for (i=1;i<staff.size();i++)
                     {
                      fox<<"\n";
                      fox << staff[i]; 
                     }
                 
                 }else fox << -1;
 fox.close();
// system ("clear");
}




int user::userread ()
{
 std::ifstream fin(username);
 int i=0,k=0;
 staff.clear();
 
 if (!fin)
        {
         return 0;
        }
  
  
  while (!fin.eof())
   {
     
                     
                  fin >> k;
                  if (k==-1) break;
                  staff.push_back(k); 
   
   
   
   }
 fin.close();
// system("clear");
 return 1; 

}